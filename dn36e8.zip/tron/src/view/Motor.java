package view;
public class Motor {
    public int x;
    public int y;
    public int velocityX;
    public int velocityY;
    public Motor(int x, int y){
        this.x = x;
        this.y = y;
        this.velocityX = 0;
        this.velocityY = 0;
    }
}
