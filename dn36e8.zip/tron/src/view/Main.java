package view;

public class Main {
    public static void startGame() {
        GUI gui = new GUI();
        gui.displayFirstScreen();
    }
    public static void main(String[] args) {
        startGame();
    }
}
